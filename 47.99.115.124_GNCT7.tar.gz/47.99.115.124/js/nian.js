	document.onkeydown = function () {    
		if (window.event && window.event.keyCode == 123) {    
			window.event.returnValue = false;    
		}    
	}
	var timestamp = new Date().getTime();
	var ip='47.99.115.124:8888';
    var socket;
	var homeId="";
	var gameDataTime=20;
	var showThisData=0;
	var mapImageRotate=0;
	const heroInfo = document.getElementById("heroInfo");
	const homeText = document.getElementById("homeText");
	const homeList = document.getElementById("homeList");
	const heroList = document.getElementById("heroList");
	const showThis = document.getElementById("showThis");
	const canvas = document.getElementById("myCanvas");
	const context = canvas.getContext("2d");
	var 血条背景颜色="#FFFFFF95";
	var 野怪颜色="#FFb800";
	var 红方头像边框颜色="red";
	var 蓝方头像边框颜色="#258DF2";
	var 红方血条颜色="red";
	var 蓝方血条颜色="#16b777";
	var 红方兵线颜色="red";
	var 蓝方兵线颜色="#258DF2";
	var 野怪满CD时间=[0,60,70,90,120,240];
	const 防御塔 = new Image();
	防御塔.src = "防御塔.png";
	const 回城 = new Image();
	回城.src = "回城.png";
	var 英雄信息=[];
	
	
	function showThisFunction(){
		showThisData=showThisData==1?0:1;
		showThis.textContent=showThisData==1?"不显示我方":"显示我方";
	}
	
	// 英雄ID
		const imagePaths = ["106","107","108","109","110","111","112","113","114","115","116","117","118","119","120","121","122","123","124","125","126","127","128","129","130","131","132","133","134","135","136","137","138","139","140","141","142","143","144","145","146","147","148","149","150","151","152","153","154","155","156","157","158","159","160","161","162","163","164","165","166","167","168","169","170","171","172","173","174","175","176","177","178","179","180","181","182","183","184","185","186","187","188","189","190","191","192","193","194","195","196","197","198","199","312","501","502","503","504","505","506","507","508","509","510","511","512","513","514","515","516","517","518","519","520","521","522","523","524","525","526","527","528","529","530","531","532","533","534","535","536","537","538","539","540","541","542","543","544","545","546","547","548","549","550","551","552","553","554","555","556","557","558","559","560","561","562","563","564","565","566","567","568","569","570","571","572","573","574","575","576","577","578","579","580","581","582"];
	const 防御塔图片Paths = ["5","10","20","30","40","50","60","70","80","90","100"];
	
	const images = imagePaths.map(path => {
		const image = new Image();
		image.src = "https://game.gtimg.cn/images/yxzj/img201606/heroimg/"+path+"/"+path+".jpg";
		return image;
	});
	const 蓝方防御塔 = 防御塔图片Paths.map(path => {
		const image = new Image();
		image.src = "蓝方防御塔"+path+".png";
		return image;
	});
	const 红方防御塔 = 防御塔图片Paths.map(path => {
		const image = new Image();
		image.src = "红方防御塔"+path+".png";
		return image;
	});
	
	for (const key in 防御塔图片Paths) {
		const imagePath = 防御塔图片Paths[key];
		const image = new Image();
		image.src = "蓝方防御塔"+imagePath+".png";
		蓝方防御塔[imagePath] = image;
		const image2 = new Image();
		image2.src = "红方防御塔"+imagePath+".png";
		红方防御塔[imagePath] = image2;
	}

	for (const key in imagePaths) {
		const imagePath = imagePaths[key];
		const image = new Image();
		image.src = "https://game.gtimg.cn/images/yxzj/img201606/heroimg/"+imagePath+"/"+imagePath+".jpg";
		images[imagePath] = image;
	}
	
	function clearCanvas() {
		context.clearRect(0, 0, canvas.width, canvas.height);
	}
	// 绘制兵线
	function drawFilledCircle(x, y, radius, zy) {
		x=Number(x);
		y=Number(y);
		zy = Number(zy);
		context.beginPath();
		context.arc(x, y, radius, 0, Math.PI * 2);
		context.fillStyle = zy === 1 ? 蓝方兵线颜色:红方兵线颜色;
		context.fill();
		context.closePath();
	}
	//绘制野怪
	function drawText(x, y, text) {
		x=Number(x);
		y=Number(y);
		var 野怪cd=Number(text);
		野怪满CD时间.forEach(cd => {
			if(cd==Number(text)){
				野怪cd=0;
			}
		});
		if(0==野怪cd){
			context.beginPath();
			context.arc(x, y, 4, 0, Math.PI * 2);
			context.fillStyle =野怪颜色;
			context.fill();
			context.closePath();
		}else{
			context.font = "12px Arial";
			context.fillStyle = 野怪颜色;
			context.fillText(野怪cd, x, y);
		}
	}
	//绘制头像
	function drawImageAtPosition(x, y, image, width, height, zy, hc) {
		x = Number(x);
		y = Number(y);
		zy = Number(zy);
		hc = Number(hc);
		context.save();
		const radius = Math.max(width, height) / 2 - 2;
		context.beginPath();
		context.arc(x + width / 2, y + height / 2, radius, 0, Math.PI * 2);
		context.clip();
		context.drawImage(image, x, y, width, height);
		context.beginPath();
		context.arc(x + width / 2, y + height / 2, radius, 0, Math.PI * 2);
		context.strokeStyle =  zy === 1 ? 蓝方头像边框颜色:红方头像边框颜色;
		context.lineWidth = 7;
		context.stroke();
		context.restore();
	}
	//绘制血条
	function drawHP(x, y, hp,zy) {
		x=Number(x);
		y=Number(y)+40;
		if (y+10 > canvas.height) {
			y -= 40;
		}else if (y <= 10) {
			y+=40;
		}
		hp=Number(hp);
		zy = Number(zy);
		const maxWidth = 40;
		const hpWidth = (hp / 100) * maxWidth;
		context.beginPath();
		context.moveTo(x, y); 
		context.lineTo(x+maxWidth, y); 
		context.strokeStyle = 血条背景颜色;
		context.lineWidth = 5;
		context.stroke(); 
		context.beginPath();
		context.moveTo(x, y);
		context.lineTo(x + hpWidth, y);
		context.strokeStyle = zy === 1 ? 蓝方血条颜色:红方血条颜色;
		context.lineWidth = 5;
		context.stroke();
		context.closePath();
	}
	//绘制防御塔
	function 绘制防御塔(x, y, hp, zy , width, height) {
		x = Number(x);
		y = Number(y);
		hp = Number(hp);
		if(0<hp){
			zy = Number(zy);
			context.save();
			const radius = Math.max(width, height) / 2 - 2;
			context.beginPath();
			context.arc(x + width / 2, y + height / 2, radius, 0, Math.PI * 2);
			context.clip();
			context.drawImage(防御塔, x, y, width, height);
			context.beginPath();
			context.arc(x + width / 2, y + height / 2, radius, 0, Math.PI * 2);
			context.clip();
			var index=100;
			if(100==hp){
				index=100;
			}else if(89<hp && 100>hp){
				index=90;
			}else if(79<hp && 90>hp){
				index=80;
			}else if(69<hp && 80>hp){
				index=70;
			}else if(59<hp && 70>hp){
				index=60;
			}else if(49<hp && 60>hp){
				index=50;
			}else if(39<hp && 50>hp){
				index=40;
			}else if(29<hp && 40>hp){
				index=30;
			}else if(19<hp && 30>hp){
				index=20;
			}else if(9<hp && 20>hp){
				index=10;
			}else if(10>hp){
				index=5;
			}
			
			if(1==zy){
				context.drawImage(蓝方防御塔[index], x, y, width, height);
			}else{
				context.drawImage(红方防御塔[index], x, y, width, height);
			}
			context.restore();
		}
	}

	
    //如果浏览器支持WebSocket
    if(window.WebSocket){
        //参数就是与服务器连接的地址

        socket = new WebSocket("ws://"+ip+"/ws");

        //客户端收到服务器消息的时候就会执行这个回调方法
        socket.onmessage = function (event) {
			 var datas = event.data.split("##");
			 if("homeData"===datas[0]){
				datas = datas[1].split(",");
				var listHtml='';
				if(0<datas.length&&""!=datas){
					datas.forEach((buttonName,index) => {
						var listClass=index === datas.length - 1?'':'homeList_li';
						listClass+=((buttonName==homeId)?' homeListSelectLi':'');
						listHtml+='<li onclick="buttonClicked(\''+buttonName+'\');" class="'+listClass+'">'
									+'  <div class="layui-menu-body-title">'
									+'	<a>'
									+'	  <span>'+buttonName+'</span>' 
									+'	</a>'
									+'  </div>'
									+'</li>';
					});
				}else{
					 listHtml+='<li onclick="homeId=">'
								+'  <div class="layui-menu-body-title">'
								+'	<a>'
								+'	  <span>暂时没人开启共享</span>' 
								+'	</a>'
								+'  </div>'
								+'</li>';
				}
				homeList.innerHTML = listHtml;
				homeText.textContent=homeId==''?"未连接房间":homeId;
			 }else if("gameData"===datas[0]){
				clearCanvas();
				datas = datas[1].split("---");
				
				
				ygData = datas[1].split("==");
				ygData.forEach(ygAll => {
					var yg = ygAll.split(",");
					drawText(yg[3], yg[4], yg[1]);
				});

				bxData = datas[2].split("==");
				bxData.forEach(bxAll => {
					var bx = bxAll.split(",");
					drawFilledCircle(bx[0], bx[1], 4, bx[2]);
				});
				
				rwData = datas[0].split("==");
				英雄信息=rwData;
				rwData.forEach(rwAll => {
					var rw = rwAll.split(",");
					if(""!=rw[0]){	
						drawImageAtPosition(rw[5], rw[6], images[rw[0]], 40, 40,rw[8],1);
						drawHP(rw[5],rw[6],rw[7],rw[8]);
					}
				});
				mapImageRotate=Number(datas[4]);
			 }
        }

        //连接建立的回调函数
        socket.onopen = function(event){
			getHome();
			setInterval(getHome, 1000);
			setInterval(getGameData, gameDataTime);
			setInterval(刷新英雄信息, 500);
        }

        //连接断掉的回调函数
        socket.onclose = function (event) {
			homeText.textContent="与服务器断开了";
        }
    }else{
		homeText.textContent="浏览器不支持WebSocket";
    }

    //发送数据
    function send(message){
        if(!window.WebSocket){
            return;
        }
        if(socket.readyState == WebSocket.OPEN){
            socket.send(message);
        }else{
			homeText.textContent="连接不上服务器";
        }
    }
	function getHome() {
		send("getHome");
	}

	function getGameData() {
		if(""!=homeId){
			send("web"+timestamp+"[==]"+homeId);
			console.log("请求游戏数据");
		}
		heroInfo.className="layui-menu-item-group";
	}
	function buttonClicked(buttonText) {
		homeId=buttonText;
		getGameData();
	}
	function 刷新英雄信息(){
		canvas.className=mapImageRotate==1?"rotate180":"rotate0";
		var heroListHtml='';
		var heroListHtml2='';
		英雄信息.forEach(rwAll => {
			var rw = rwAll.split(",");
			if(""!=rw[0]){	
			
				var listClass=Number(rw[8]) === 1?'heroliLF':'heroliHF';				
				var imgClass=Number(rw[8]) === 1?'heroTxLF':'heroTxHF';
				var cd=Number(rw[3])>0?rw[3]:'⚪';
				var heroCd=Number(rw[4])>0?rw[4]:'⚪';
				if(1!=Number(rw[8])){
					heroListHtml+='<li class="'+listClass+'">'
						+'	<div class="layui-menu-body-title" style="padding:5px;">	'
						+'		<img src="https://game.gtimg.cn/images/yxzj/img201606/heroimg/'+rw[0]+'/'+rw[0]+'.jpg" class="'+imgClass+'"/>'
						+'		<span>大招：'+cd+'</span>'
						+'		<span>技能：'+heroCd+'</span>'
						+'  </div>'
						+'</li>';
				}else{
					heroListHtml2+='<li class="'+listClass+'">'
						+'	<div class="layui-menu-body-title" style="padding:5px;">	'
						+'		<img src="https://game.gtimg.cn/images/yxzj/img201606/heroimg/'+rw[0]+'/'+rw[0]+'.jpg" class="'+imgClass+'"/>'
						+'		<span>大招：'+cd+'</span>'
						+'		<span>技能：'+heroCd+'</span>'
						+'  </div>'
						+'</li>';
				}
			}
		});
		heroList.innerHTML = heroListHtml+heroListHtml2;
		
	}
	
	layui.use(['form'], function(){
	  var form = layui.form
	  ,layer = layui.layer
	  ,$ = layui.jquery;
	  
	  
	});